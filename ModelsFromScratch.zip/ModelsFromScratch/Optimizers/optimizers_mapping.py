from Optimizers.optimizers import *

optimizers_mapping = {
    'gradient_descent': GradientDescent,
    'sgd': SGD
}